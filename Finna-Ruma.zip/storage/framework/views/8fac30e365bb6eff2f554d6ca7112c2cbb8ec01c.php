
<div class="flex items-start">
    <div class="flex items-center h-5">
        <input id="smoking_allowed" name="smoking_allowed" type="checkbox"
            <?php if(!empty($listing)): ?> <?php if($listing->listing_amenity->smoking_allowed): echo 'checked'; endif; ?> <?php endif; ?>
            class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded">
    </div>
    <div class="ml-3 text-sm">
        <label for="smoking_allowed" class="font-medium text-gray-700">Smoking Allowed</label>
    </div>
</div>


<div class="flex items-start">
    <div class="flex items-center h-5">
        <input id="free_parking" name="free_parking" type="checkbox"
            <?php if(!empty($listing)): ?> <?php if($listing->listing_amenity->free_parking): echo 'checked'; endif; ?> <?php endif; ?>
            class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded">
    </div>
    <div class="ml-3 text-sm">
        <label for="free_parking" class="font-medium text-gray-700">Free Parking</label>
    </div>
</div>



<div class="flex items-start">
    <div class="flex items-center h-5">
        <input id="breakfast" name="breakfast" type="checkbox"
            <?php if(!empty($listing)): ?> <?php if($listing->listing_amenity->breakfast): echo 'checked'; endif; ?> <?php endif; ?>
            class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded">
    </div>
    <div class="ml-3 text-sm">
        <label for="breakfast" class="font-medium text-gray-700">Breakfast</label>

    </div>
</div>


<div class="flex items-start">
    <div class="flex items-center h-5">
        <input id="smoke_alarm" name="smoke_alarm" type="checkbox"
            <?php if(!empty($listing)): ?> <?php if($listing->listing_amenity->smoke_alarm): echo 'checked'; endif; ?> <?php endif; ?>
            class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded">
    </div>
    <div class="ml-3 text-sm">
        <label for="smoke_alarm" class="font-medium text-gray-700">Smoke Alarm</label>
    </div>
</div>


<div class="flex items-start">
    <div class="flex items-center h-5">
        <input id="carbon_monoxide_alarm" name="carbon_monoxide_alarm" type="checkbox"
            <?php if(!empty($listing)): ?> <?php if($listing->listing_amenity->carbon_monoxide_alarm): echo 'checked'; endif; ?> <?php endif; ?>
            class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded">
    </div>
    <div class="ml-3 text-sm">
        <label for="carbon_monoxide_alarm" class="font-medium text-gray-700">Carbon Monoxide Alarm</label>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Finna-Ruma\resources\views/pages/host/amenity-3.blade.php ENDPATH**/ ?>