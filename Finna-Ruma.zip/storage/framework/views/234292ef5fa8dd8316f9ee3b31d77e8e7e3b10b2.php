<div class="flex items-start">
    <div class="flex items-center h-5">
        <input id="wifi" name="wifi" type="checkbox"
            <?php if(!empty($listing)): ?> <?php if($listing->listing_amenity->wifi): echo 'checked'; endif; ?> <?php endif; ?>
            class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded">
    </div>
    <div class="ml-3 text-sm">
        <label for="wifi" class="font-medium text-gray-700">Wifi</label>
        
    </div>
</div>

<div class="flex items-start">
    <div class="flex items-center h-5">
        <input id="washer" name="washer" type="checkbox"
            <?php if(!empty($listing)): ?> <?php if($listing->listing_amenity->washer): echo 'checked'; endif; ?> <?php endif; ?>
            class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded">
    </div>
    <div class="ml-3 text-sm">
        <label for="washer" class="font-medium text-gray-700">Washer</label>
    </div>
</div>

<div class="flex items-start">
    <div class="flex items-center h-5">
        <input id="air_conditioning" name="air_conditioning" type="checkbox"
            <?php if(!empty($listing)): ?> <?php if($listing->listing_amenity->air_conditioning): echo 'checked'; endif; ?> <?php endif; ?>
            class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded">
    </div>
    <div class="ml-3 text-sm">
        <label for="air_conditioning" class="font-medium text-gray-700">Air
            Conditioning</label>
    </div>
</div>




<div class="flex items-start">
    <div class="flex items-center h-5">
        <input id="dedicated_workspace" name="dedicated_workspace" type="checkbox"
            <?php if(!empty($listing)): ?> <?php if($listing->listing_amenity->dedicated_workspace): echo 'checked'; endif; ?> <?php endif; ?>
            class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded">
    </div>
    <div class="ml-3 text-sm">
        <label for="dedicated_workspace" class="font-medium text-gray-700">Dedicated Workspace</label>
    </div>
</div>


<div class="flex items-start">
    <div class="flex items-center h-5">
        <input id="hair_dryer" name="hair_dryer" type="checkbox"
            <?php if(!empty($listing)): ?> <?php if($listing->listing_amenity->hair_dryer): echo 'checked'; endif; ?> <?php endif; ?>
            class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded">
    </div>
    <div class="ml-3 text-sm">
        <label for="hair_dryer" class="font-medium text-gray-700">Hair Dryer</label>
    </div>
</div>


<div class="flex items-start">
    <div class="flex items-center h-5">
        <input id="pool" name="pool" type="checkbox"
            <?php if(!empty($listing)): ?> <?php if($listing->listing_amenity->pool): echo 'checked'; endif; ?> <?php endif; ?>
            class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded">
    </div>
    <div class="ml-3 text-sm">
        <label for="pool" class="font-medium text-gray-700">Pool</label>
    </div>
</div>




<div class="flex items-start">
    <div class="flex items-center h-5">
        <input id="crib" name="crib" type="checkbox"
            <?php if(!empty($listing)): ?> <?php if($listing->listing_amenity->crib): echo 'checked'; endif; ?> <?php endif; ?>
            class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded">
    </div>
    <div class="ml-3 text-sm">
        <label for="crib" class="font-medium text-gray-700">Crib</label>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Finna-Ruma\resources\views/pages/host/amenity-1.blade.php ENDPATH**/ ?>