
<div class="flex items-start">
    <div class="flex items-center h-5">
        <input id="grill" name="grill" type="checkbox"
            <?php if(!empty($listing)): ?> <?php if($listing->listing_amenity->grill): echo 'checked'; endif; ?> <?php endif; ?>
            class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded">
    </div>
    <div class="ml-3 text-sm">
        <label for="grill" class="font-medium text-gray-700">Grill</label>
    </div>
</div>


<div class="flex items-start">
    <div class="flex items-center h-5">
        <input id="gym" name="gym" type="checkbox"
            <?php if(!empty($listing)): ?> <?php if($listing->listing_amenity->gym): echo 'checked'; endif; ?> <?php endif; ?>
            class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded">
    </div>
    <div class="ml-3 text-sm">
        <label for="gym" class="font-medium text-gray-700">Gym</label>
    </div>
</div>



<div class="flex items-start">
    <div class="flex items-center h-5">
        <input id="heating" name="heating" type="checkbox"
            <?php if(!empty($listing)): ?> <?php if($listing->listing_amenity->heating): echo 'checked'; endif; ?> <?php endif; ?>
            class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded">
    </div>
    <div class="ml-3 text-sm">
        <label for="heating" class="font-medium text-gray-700">Heating</label>
    </div>
</div>


<div class="flex items-start">
    <div class="flex items-center h-5">
        <input id="tv" name="tv" type="checkbox"
            <?php if(!empty($listing)): ?> <?php if($listing->listing_amenity->tv): echo 'checked'; endif; ?> <?php endif; ?>
            class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded">
    </div>
    <div class="ml-3 text-sm">
        <label for="tv" class="font-medium text-gray-700">TV</label>
    </div>
</div>


<div class="flex items-start">
    <div class="flex items-center h-5">
        <input id="iron" name="iron" type="checkbox"
            <?php if(!empty($listing)): ?> <?php if($listing->listing_amenity->iron): echo 'checked'; endif; ?> <?php endif; ?>
            class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded">
    </div>
    <div class="ml-3 text-sm">
        <label for="iron" class="font-medium text-gray-700">Iron</label>
    </div>
</div>


<div class="flex items-start">
    <div class="flex items-center h-5">
        <input id="kitchen" name="kitchen" type="checkbox"
            <?php if(!empty($listing)): ?> <?php if($listing->listing_amenity->kitchen): echo 'checked'; endif; ?> <?php endif; ?>
            class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded">
    </div>
    <div class="ml-3 text-sm">
        <label for="kitchen" class="font-medium text-gray-700">Kitchen</label>
    </div>
</div>


<div class="flex items-start">
    <div class="flex items-center h-5">
        <input id="dryer" name="dryer" type="checkbox"
            <?php if(!empty($listing)): ?> <?php if($listing->listing_amenity->dryer): echo 'checked'; endif; ?> <?php endif; ?>
            class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 rounded">
    </div>
    <div class="ml-3 text-sm">
        <label for="dryer" class="font-medium text-gray-700">Dryer</label>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Finna-Ruma\resources\views/pages/host/amenity-2.blade.php ENDPATH**/ ?>