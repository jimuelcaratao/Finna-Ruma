<div class="grid grid-cols-4 gap-4">

    <?php if($listing->listing_rule->garbage_disposal == true): ?>
        <div class="relative inline-flex items-center w-full  py-1  text-sm  ">
            <img src="<?php echo e(asset('img/global/icons/garbage.png')); ?>" class="h-6 w-6 mr-3">
            Garbage Disposal
        </div>
    <?php endif; ?>


    <?php if($listing->listing_rule->curfew !== null): ?>
        <div class="relative inline-flex items-center w-full  py-1  text-sm ">
            <img src="<?php echo e(asset('img/global/icons/clock.png')); ?>" class="h-6 w-6 mr-3">
            Curfew time: <?php echo e($listing->listing_rule->curfew); ?>

        </div>
    <?php endif; ?>



    <?php if($listing->listing_rule->claygo == true): ?>
        <div class="relative inline-flex items-center w-full py-1  text-sm ">
            <img src="<?php echo e(asset('img/global/icons/broom.png')); ?>" class="h-6 w-6 mr-3">
            Clean as you go
        </div>
    <?php endif; ?>

    <?php if($listing->listing_rule->no_smoking == true): ?>
        <div class="relative inline-flex items-center w-full py-1  text-sm ">
            <img src="<?php echo e(asset('img/global/icons/no-smoking.png')); ?>" class="h-6 w-6 mr-3">
            No Smoking
        </div>
    <?php endif; ?>

    <?php if($listing->listing_rule->no_drinking == true): ?>
        <div class="relative inline-flex items-center w-full py-1  text-sm ">
            <img src="<?php echo e(asset('img/global/icons/no-alcohol.png')); ?>" class="h-6 w-6 mr-3">
            No Drinking
        </div>
    <?php endif; ?>

    <?php if($listing->listing_rule->no_pets == true): ?>
        <div class="relative inline-flex items-center w-full py-1  text-sm ">
            <img src="<?php echo e(asset('img/global/icons/no-animals.png')); ?>" class="h-6 w-6 mr-3">
            No Pets Allowed
        </div>
    <?php endif; ?>



    <?php if($listing->listing_rule->no_events == true): ?>
        <div class="relative inline-flex items-center w-full py-1  text-sm ">
            <img src="<?php echo e(asset('img/global/icons/celebrate.png')); ?>" class="h-6 w-6 mr-3">
            No Parties/Events
        </div>
    <?php endif; ?>


</div>
<?php /**PATH C:\xampp\htdocs\Finna-Ruma\resources\views/pages/single-post-components/house-rules.blade.php ENDPATH**/ ?>