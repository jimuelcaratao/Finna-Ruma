<div>
    <form class="flex justify-center items-center w-screen px-8 md:px-12">
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input','data' => ['class' => 'relative w-full','type' => 'text','placeholder' => 'Listing name or category','wire:model' => 'search','wire:keydown.escape' => 'resetSearch']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'relative w-full','type' => 'text','placeholder' => 'Listing name or category','wire:model' => 'search','wire:keydown.escape' => 'resetSearch']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    </form>
    
    <div class="px-8 md:px-12 absolute top-18 left-0 z-40 bg-gray-50 w-full rounded-b-md">
        <div class="max-h-72 overflow-auto divide-y divide-gray-200">
            <?php if(!empty($search)): ?>
                

                <div>
                    <?php $__empty_1 = true; $__currentLoopData = $listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <a href="<?php echo e(route('single-list', [$listing->slug])); ?>"
                            class="flex flex-row py-2 hover:bg-gray-100">
                            <img src="<?php echo e(asset('storage/media/listing/cover_' . $listing->listing_id . '_' . $listing->default_photo)); ?>"
                                class="h-auto w-20 mr-3" alt="<?php echo e($listing->listing_title); ?>'s image">
                            <div class="flex flex-col space-y-2">
                                <p class="text-gray-900"><?php echo e($listing->listing_title); ?></p>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <a class="px-5 py-2 overscroll-none">No Article found...</a>
                    <?php endif; ?>
                </div>

            <?php endif; ?>

        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Finna-Ruma\resources\views/livewire/search.blade.php ENDPATH**/ ?>