<?php if (isset($component)) { $__componentOriginal5166c0e64f8fa13f0ef83a121d0e097bbcd4aa85 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GlobalLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('global-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\GlobalLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <?php $__env->startPush('styles'); ?>
        <style>
            .mapouter {
                position: relative;
                text-align: right;
                height: 500px;
                width: 100%;
            }

            .gmap_canvas {
                overflow: hidden;
                background: none !important;
                height: 500px;
                width: 100%;

            }

            input:checked+label {
                border-color: #979797;
                box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
                transition: ease-out .2s;
            }


            input[type="number"] {
                -webkit-appearance: textfield;
                -moz-appearance: textfield;
                appearance: textfield;
            }

            input[type="number"]::-webkit-inner-spin-button,
            input[type="number"]::-webkit-outer-spin-button {
                -webkit-appearance: none;
            }

            .number-input {
                display: inline-flex;
            }

            .number-input,
            .number-input * {
                box-sizing: border-box;
            }

            .number-input button {
                outline: none;
                -webkit-appearance: none;
                background-color: #ffffff;
                border: none;
                align-items: center;
                justify-content: center;
                width: 40px;
                cursor: pointer;
                margin: 0;
                position: relative;
                padding: 0;
                border-radius: 40px;
                border: 2px solid #ddd;

            }

            .number-input button:hover {
                background-color: #f8f8f8;
            }

            .number-input button:before,
            .number-input button:after {
                display: inline-block;
                position: absolute;
                content: "";
                width: 0.5rem;
                height: 2px;
                background-color: #212121;
                transform: translate(-50%, -50%);
            }

            .number-input button.plus:after {
                transform: translate(-50%, -50%) rotate(90deg);
            }

            .number-input input[type="number"] {
                font-family: sans-serif;
                max-width: 4.5rem;
                padding: 0.5rem;
                border: 0;
                text-align: center;
                outline: none;
            }

            .number-input {}

            .text-star {
                background-color: gold;
            }
        </style>
    <?php $__env->stopPush(); ?>
    <div class="lg:pb-12 lg:pt-6">
        <div class="max-w-screen-2xl mx-auto sm:px-6 lg:px-24">


            
            <div>
                <div class="container mx-auto">

                    <div class="flex justify-center lg:my-8">
                        <!-- Row -->
                        <div class="w-full flex-1 md:flex">

                            <!-- Col -->
                            <div class="flex-initial w-full lg:w-3/5 lg:block bg-white lg:mr-10 px-4 lg:px-0">
                                <div class=" mb-4">

                                    <div class="flex justify-between gap-10">
                                        <div>
                                            <h3 class="pt-4 mb-2 text-3xl font-semibold">
                                                Booking ID: <?php echo e($booking->booking_id); ?>

                                            </h3>
                                            <span
                                                class="mt-4 mb-2 bg-blue-100 text-blue-800 text-sm font-medium inline-flex items-center px-2.5 py-0.5 rounded ">

                                                <?php echo e($booking->booking_status); ?>

                                            </span>
                                            <span
                                                class="mt-4 mb-2 bg-blue-100 text-blue-800 text-sm font-medium inline-flex items-center px-2.5 py-0.5 rounded ">

                                                <?php echo e($booking->host_status); ?>

                                            </span>
                                            <h3 class=" mb-2 text-xl "><?php echo e($booking->listing->listing_title); ?>

                                            </h3>
                                            <a class="text-sm font-medium text-gray-700 underline">
                                                <?php echo e($booking->listing->location); ?></a>

                                            <!-- Breadcrumb -->
                                            <nav class="flex" aria-label="Breadcrumb">
                                                <ol class="inline-flex items-center space-x-1 md:space-x-3">
                                                    <li class="inline-flex items-center">
                                                        <span
                                                            class="inline-flex items-center text-sm font-medium text-gray-700">
                                                            <?php echo e($booking->listing->max_guest); ?> guests
                                                        </span>
                                                    </li>
                                                    <li>
                                                        <div class="flex items-center">
                                                            <span class="mx-1">
                                                                •
                                                            </span>
                                                            <span
                                                                class="ml-1 text-sm font-medium text-gray-700 md:ml-2 "><?php echo e($booking->listing->bedrooms); ?>

                                                                bedrooms</span>
                                                        </div>
                                                    </li>
                                                    <li aria-current="page">
                                                        <div class="flex items-center">
                                                            <span class="mx-1">
                                                                •
                                                            </span>

                                                            <span
                                                                class="ml-1 text-sm font-medium text-gray-700 md:ml-2"><?php echo e($booking->listing->beds); ?>

                                                                beds</span>
                                                        </div>
                                                    </li>

                                                    <li aria-current="page">
                                                        <div class="flex items-center">
                                                            <span class="mx-1">
                                                                •
                                                            </span>

                                                            <span
                                                                class="ml-1 text-sm font-medium text-gray-700 md:ml-2"><?php echo e($booking->listing->bathrooms); ?>

                                                                baths
                                                            </span>
                                                        </div>
                                                    </li>
                                                </ol>
                                            </nav>

                                            <div class=" inline-flex mt-4 ">
                                                <?php if(Laravel\Jetstream\Jetstream::managesProfilePhotos()): ?>
                                                    <span
                                                        class="flex text-sm border-2 border-transparent rounded-full focus:outline-none focus:border-gray-300 transition">
                                                        <img class="h-12 w-12 rounded-full object-cover"
                                                            src="<?php echo e($booking->listing->user->profile_photo_url); ?>"
                                                            alt="<?php echo e($booking->listing->user->name); ?>" />
                                                    </span>
                                                <?php else: ?>
                                                    <span class="inline-flex rounded-md">
                                                        <span
                                                            class="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-gray-500 bg-white hover:text-gray-700 focus:outline-none transition">
                                                            <?php echo e($booking->listing->user->name); ?>


                                                            <svg class="ml-2 -mr-0.5 h-5 w-5"
                                                                xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"
                                                                fill="currentColor">
                                                                <path fill-rule="evenodd"
                                                                    d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                                                                    clip-rule="evenodd" />
                                                            </svg>
                                                        </span>
                                                    </span>
                                                <?php endif; ?>
                                                <span class="align-middle mt-4 ml-2 font-bold text-sm">
                                                    Hosted by: <?php echo e($booking->listing->user->name); ?></span>
                                            </div>

                                            
                                            <div class="mt-8">
                                                <h5 class="text-lg font-bold mb-2">Your Trip</h5>

                                                <h3 class=" font-bold">Dates</h3>
                                                <span class="text-sm"><?php echo e($booking->check_in); ?> -
                                                    <?php echo e($booking->checkout); ?> </span>

                                                <h3 class=" font-bold mt-2">Guests</h3>
                                                <span class="text-sm"><?php echo e($booking->adults); ?> Occupant/s</span>

                                                <h3 class=" font-bold mt-2">Payment Status</h3>
                                                <span class="text-sm"><?php echo e($booking->payment_status); ?></span>
                                            </div>

                                        </div>
                                    </div>


                                </div>

                            </div>




                            <!-- Payment Section -->
                            <div class="flex-initial  w-full lg:w-2/5 ">
                                <div class=" mb-4 p-6 mt-4 shadow-md border-2 border-gray-300 lg:rounded-lg">



                                    <div class=" mb-6 text-2xl font-semibold">
                                        Price details
                                    </div>


                                    <div class="">
                                        <div class="flex items-center justify-between w-full md:w-2/4">
                                            <div>
                                                <h3 class="text-base text-gray-900 underline">₱ <?php echo number_format($booking->price_per_night, 2); ?> ×
                                                    <?php echo e($booking->days); ?></h3>
                                            </div>
                                            <div class="mt-2">
                                                ₱ <?php echo e($booking->pending_total); ?>

                                            </div>
                                        </div>
                                    </div>


                                    <div class="mt-4">
                                        <div class="flex items-center justify-between w-full md:w-2/4">
                                            <div>
                                                <h3 class="text-base text-gray-900 underline">Service Fee</h3>
                                            </div>
                                            <div class="mt-2">
                                                ₱ <?php echo number_format($booking->service_fee, 2); ?>
                                            </div>
                                        </div>
                                    </div>

                                    <?php if($booking->payment_status == 'Half Paid'): ?>
                                        <div class="mt-6">
                                            <div class="flex items-center justify-between w-full md:w-2/4">
                                                <div>
                                                    <h3 class="text-base text-gray-900 font-bold">Paid</h3>
                                                </div>
                                                <div class="mt-2">
                                                    <h3 class=" text-lg font-semibold">₱
                                                        <?php echo number_format($booking->total_paid, 2); ?></h3>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="">
                                            <div class="flex items-center justify-between w-full md:w-2/4">
                                                <div>
                                                    <h3 class="text-base text-gray-900 font-bold">Balance</h3>
                                                </div>
                                                <div class="mt-2">
                                                    <h3 class=" text-lg font-semibold">₱
                                                        <?php echo number_format($booking->total - $booking->total_paid, 2); ?></h3>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>

                                    <div class="mt-2">
                                        <div class="flex items-center justify-between w-full md:w-2/4">
                                            <div>
                                                <h3 class="text-base text-gray-900 font-bold">Total</h3>
                                            </div>
                                            <div class="mt-2">
                                                <h3 class=" mb-4 text-xl font-semibold">₱
                                                    <?php echo number_format($booking->total, 2); ?></h3>
                                            </div>
                                        </div>
                                    </div>



                                    <div class="border-b-2 border-gray-30 my-6"></div>

                                    <?php if($booking->payment_status == 'Half Paid'): ?>
                                        
                                        <form action="<?php echo e(route('complete_payment.booking', [$booking->booking_id])); ?>"
                                            method="POST" id="payment">
                                            <?php echo csrf_field(); ?>

                                        </form>

                                        <div id="paypal-button-container"></div>
                                    <?php endif; ?>


                                    <div class="text-right">

                                        

                                        <?php if($booking->booking_status == 'Waiting for payment proof'): ?>
                                            <a
                                                href="<?php echo e(route('submit_receipt', [$booking->booking_id, $booking->listing->listing_id])); ?>">
                                                <button type="button"
                                                    class=" text-gray-900 bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-200 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 ">
                                                    Submit receipt
                                                </button>
                                            </a>

                                            <a href="<?php echo e(route('booking', [$booking->booking_id])); ?>">
                                                <button type="button"
                                                    class=" text-gray-900 bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-200 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 ">
                                                    View
                                                </button>
                                            </a>
                                        <?php endif; ?>

                                        <?php if($booking->booking_status == 'Waiting for payment approval'): ?>
                                            <a href="<?php echo e(route('my-bookings')); ?>">
                                                <button type="button"
                                                    class=" text-gray-900 bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-200 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 ">
                                                    Go to my bookings
                                                </button>
                                            </a>
                                        <?php endif; ?>


                                        <?php if($booking->booking_status == 'Pending Confirmation'): ?>
                                            <a
                                                href="<?php echo e(route('confirm-booking', [$booking->listing->slug, $booking->booking_id])); ?>">
                                                <button type="button"
                                                    class=" text-gray-900 bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-200 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 ">
                                                    Confirm
                                                </button>
                                            </a>
                                        <?php endif; ?>

                                        <?php if($booking->booking_status == 'Confirmed Reservation'): ?>
                                            <a href="<?php echo e(route('my-bookings')); ?>">
                                                <button type="button"
                                                    class=" text-gray-900 bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-200 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 ">
                                                    Go to my bookings
                                                </button>
                                            </a>
                                        <?php endif; ?>

                                        <?php if($booking->booking_status == 'Complete'): ?>
                                            <?php if($booking->reviewed_at == null): ?>
                                                <a
                                                    href="<?php echo e(route('write_review', [$booking->booking_id, $booking->listing->listing_id])); ?>">
                                                    <button type="button"
                                                        class=" text-gray-900 bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-200 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 ">
                                                        Review
                                                    </button>
                                                </a>
                                            <?php else: ?>
                                                <a href="<?php echo e(route('my-bookings')); ?>">
                                                    <button type="button"
                                                        class=" text-gray-900 bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-200 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 ">
                                                        Go to my bookings
                                                    </button>
                                                </a>
                                            <?php endif; ?>
                                        <?php endif; ?>



                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>



                </div>
            </div>

        </div>
    </div>



    <?php $__env->startPush('scripts'); ?>
        <script src="https://unpkg.com/flowbite@1.4.7/dist/flowbite.js"></script>
        <script src="https://unpkg.com/flowbite@1.4.7/dist/datepicker.js"></script>
        <script
            src="https://www.paypal.com/sdk/js?client-id=AX0Ff2y0zUSeiMumlF0aYvHyeQ5FFkK7VwGY6QCR5iRUybBGzPOPtavGFpjER-kWUTDLf48YAOBh_jap&currency=PHP">
        </script>

        <script>
            function textAreaAdjust(element) {
                element.style.height = "1px";
                element.style.height = (25 + element.scrollHeight) + "px";
            }

            $(document).ready(function() {
                total = '<?php echo e($booking->total); ?>';
                total_paid = '<?php echo e($booking->total_paid); ?>';
                final_payment = total - total_paid;





                paypal.Buttons({
                    // Sets up the transaction when a payment button is clicked
                    createOrder: function(data, actions) {



                        return actions.order.create({
                            purchase_units: [{
                                amount: {
                                    value: final_payment // Can reference variables or functions. Example: `value: document.getElementById('...').value`
                                }
                            }]
                        });
                    },

                    // Finalize the transaction after payer approval
                    onApprove: function(data, actions) {
                        return actions.order.capture().then(function(orderData) {
                            // Successful capture! For dev/demo purposes:
                            console.log('Capture result', orderData, JSON.stringify(orderData, null,
                                2));
                            var transaction = orderData.purchase_units[0].payments.captures[0];
                            alert('Transaction ' + transaction.status + ': ' + transaction.id +
                                '\n\nSee console for all available details');

                            $('form#payment').submit();
                        });
                    }
                }).render('#paypal-button-container');

                var pending = $('#pending-total');
                var total_days = $('#total-days');
                var price_night = $('#price_night').val();
                var service_fee = $('#service_fee').val();


                function treatAsUTC(date) {
                    var result = new Date(date);
                    result.setMinutes(result.getMinutes() - result.getTimezoneOffset());
                    return result;
                }

                function daysBetween(startDate, endDate) {
                    var millisecondsPerDay = 24 * 60 * 60 * 1000;
                    return (treatAsUTC(endDate) - treatAsUTC(startDate)) / millisecondsPerDay;
                }


                $('#check-in').focusout(function() {
                    var first = $('#check-in').val();
                    var second = $('#checkout').val();
                    var days = daysBetween(first, second);

                    $('#total-days').text(days);

                    $('#days').val(days);
                    $('#pending-total').val((price_night * days).toLocaleString());

                    var service = parseInt(service_fee);
                    var get_total = (price_night * days) + service;
                    $('#total').val((get_total).toLocaleString());
                    $('#total-fee').show();

                });

                $('#checkout').focusout(function() {
                    var first = $('#check-in').val();
                    var second = $('#checkout').val();
                    var days = daysBetween(first, second);

                    $('#total-days').text(days);
                    $('#pending-total').val((price_night * days).toLocaleString());

                    var service = parseInt(service_fee);
                    var get_total = (price_night * days) + service;
                    $('#total').val((get_total).toLocaleString());
                    $('#total-fee').show();

                });

            });
        </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5166c0e64f8fa13f0ef83a121d0e097bbcd4aa85)): ?>
<?php $component = $__componentOriginal5166c0e64f8fa13f0ef83a121d0e097bbcd4aa85; ?>
<?php unset($__componentOriginal5166c0e64f8fa13f0ef83a121d0e097bbcd4aa85); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Finna-Ruma\resources\views/pages/booking.blade.php ENDPATH**/ ?>