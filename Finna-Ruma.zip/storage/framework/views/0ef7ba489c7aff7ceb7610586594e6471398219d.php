<?php if (isset($component)) { $__componentOriginal5166c0e64f8fa13f0ef83a121d0e097bbcd4aa85 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GlobalLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('global-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\GlobalLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <?php $__env->startPush('styles'); ?>
        <style>
            .mapouter {
                position: relative;
                text-align: right;
                height: 500px;
                width: 100%;
            }

            .gmap_canvas {
                overflow: hidden;
                background: none !important;
                height: 500px;
                width: 100%;

            }

            input:checked+label {
                border-color: #979797;
                box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
                transition: ease-out .2s;
            }


            input[type="number"] {
                -webkit-appearance: textfield;
                -moz-appearance: textfield;
                appearance: textfield;
            }

            input[type="number"]::-webkit-inner-spin-button,
            input[type="number"]::-webkit-outer-spin-button {
                -webkit-appearance: none;
            }

            .number-input {
                display: inline-flex;
            }

            .number-input,
            .number-input * {
                box-sizing: border-box;
            }

            .number-input button {
                outline: none;
                -webkit-appearance: none;
                background-color: #ffffff;
                border: none;
                align-items: center;
                justify-content: center;
                width: 40px;
                cursor: pointer;
                margin: 0;
                position: relative;
                padding: 0;
                border-radius: 40px;
                border: 2px solid #ddd;

            }

            .number-input button:hover {
                background-color: #f8f8f8;
            }

            .number-input button:before,
            .number-input button:after {
                display: inline-block;
                position: absolute;
                content: "";
                width: 0.5rem;
                height: 2px;
                background-color: #212121;
                transform: translate(-50%, -50%);
            }

            .number-input button.plus:after {
                transform: translate(-50%, -50%) rotate(90deg);
            }

            .number-input input[type="number"] {
                font-family: sans-serif;
                max-width: 4.5rem;
                padding: 0.5rem;
                border: 0;
                text-align: center;
                outline: none;
            }

            .number-input {}

            .text-star {
                background-color: gold;
            }
        </style>
    <?php $__env->stopPush(); ?>
    <div class="lg:pb-12 lg:pt-6">
        <div class="max-w-screen-2xl mx-auto sm:px-6 lg:px-24">

            
            <div>
                <div class="container mx-auto">


                    <h3 class="font-bold text-4xl mt-6">My bookings</h3>

                    <div class="flex justify-center lg:my-8">

                        <!-- Row -->
                        <div class="w-full flex-1 md:flex gap-10">

                            <div class="grid grid-cols-3 gap-10">
                                <?php $__empty_1 = true; $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <!-- Cards -->
                                    <div class="flex-initial  w-full ">
                                        <div class=" mb-4 p-6 mt-4 shadow-md border-2 border-gray-300 lg:rounded-lg">



                                            <div class="inline-flex ">
                                                <a href="<?php echo e(route('single-list', [$booking->listing->slug])); ?>"> <img
                                                        src="<?php echo e(asset('storage/media/listing/cover_' . $booking->listing->listing_id . '_' . $booking->listing->default_photo)); ?>"
                                                        class="w-58 h-36 rounded-md">
                                                </a>
                                                <div class="pl-4">
                                                    <span
                                                        class="mb-2 bg-blue-100 text-blue-800 text-xs font-medium inline-flex items-center px-2.5 py-0.5 rounded ">

                                                        <?php echo e($booking->booking_status); ?>

                                                    </span>

                                                    <a href="<?php echo e(route('single-list', [$booking->listing->slug])); ?>"
                                                        class="font-bold text-sm block">
                                                        <?php echo e($booking->listing->listing_title); ?>


                                                    </a>
                                                    <a class="text-xs font-medium text-gray-700 underline">
                                                        <?php echo e($booking->listing->location); ?></a>
                                                    <p class="text-xs text-gray-700"><?php echo e($booking->listing->max_guest); ?>

                                                        guests•<?php echo e($booking->listing->beds); ?>

                                                        beds•<?php echo e($booking->listing->bathrooms); ?>

                                                        baths</p>
                                                </div>

                                            </div>
                                            <div class="border-b-2 border-gray-30 my-5"></div>

                                            <div class="mt-8">
                                                <h5 class="text-lg font-bold mb-2">Your Trip</h5>

                                                <h3 class=" font-bold">Dates <span
                                                        class="text-sm text-gray-400 font-normal">(<?php echo e($booking->days); ?>

                                                        days)</span></h3>
                                                <span class="text-sm"><?php echo e($booking->check_in); ?> -
                                                    <?php echo e($booking->checkout); ?></span>

                                                <h3 class=" font-bold mt-2">Guests</h3>
                                                <span class="text-sm"><?php echo e($booking->adults); ?> Occupant/s
                                                </span>

                                                <h3 class=" font-bold mt-2">Payment Status</h3>
                                                <span class="text-sm"><?php echo e($booking->payment_status); ?></span>
                                            </div>


                                            <div class="border-b-2 border-gray-30 my-5"></div>
                                            <div class="text-right">

                                                <?php if($booking->booking_status == 'Waiting for payment approval'): ?>
                                                    <a href="<?php echo e(route('booking', [$booking->booking_id])); ?>">
                                                        <button type="button"
                                                            class=" text-gray-900 bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-200 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 ">
                                                            View
                                                        </button>
                                                    </a>
                                                <?php endif; ?>

                                                <?php if($booking->booking_status == 'Waiting for payment proof'): ?>
                                                    <a
                                                        href="<?php echo e(route('submit_receipt', [$booking->booking_id, $booking->listing->listing_id])); ?>">
                                                        <button type="button"
                                                            class=" text-gray-900 bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-200 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 ">
                                                            Submit receipt
                                                        </button>
                                                    </a>

                                                    <a href="<?php echo e(route('booking', [$booking->booking_id])); ?>">
                                                        <button type="button"
                                                            class=" text-gray-900 bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-200 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 ">
                                                            View
                                                        </button>
                                                    </a>
                                                <?php endif; ?>


                                                <?php if($booking->booking_status == 'Pending Confirmation'): ?>
                                                    <div class="inline-flex">
                                                        <a
                                                            href="<?php echo e(route('confirm-booking', [$booking->listing->slug, $booking->booking_id])); ?>">
                                                            <button type="button"
                                                                class=" text-gray-900 bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-200 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 ">
                                                                Confirm
                                                            </button>
                                                        </a>

                                                        <form class="delete-listing ml-2"
                                                            action="<?php echo e(route('cancel.booking', [$booking->booking_id])); ?>"
                                                            method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <a type="submit">
                                                                <button type="button"
                                                                    class=" text-gray-900 bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-200 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 ">
                                                                    Cancel
                                                                </button>
                                                            </a>
                                                        </form>
                                                    </div>
                                                <?php endif; ?>

                                                <?php if($booking->booking_status == 'Confirmed Reservation'): ?>
                                                    <a href="<?php echo e(route('booking', [$booking->booking_id])); ?>">
                                                        <button type="button"
                                                            class=" text-gray-900 bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-200 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 ">
                                                            View
                                                        </button>
                                                    </a>
                                                <?php endif; ?>

                                                <?php if($booking->booking_status == 'Complete'): ?>
                                                    <?php if($booking->reviewed_at == null): ?>
                                                        <a
                                                            href="<?php echo e(route('write_review', [$booking->booking_id, $booking->listing->listing_id])); ?>">
                                                            <button type="button"
                                                                class=" text-gray-900 bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-200 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 ">
                                                                Review
                                                            </button>
                                                        </a>
                                                    <?php else: ?>
                                                        <a
                                                            href="<?php echo e(route('single-list', [$booking->listing->slug])); ?>">
                                                            <button type="button"
                                                                class=" text-gray-900 bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-200 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 ">
                                                                Book Again
                                                            </button>
                                                        </a>

                                                        <a href="<?php echo e(route('booking', [$booking->booking_id])); ?>">
                                                            <button type="button"
                                                                class=" text-gray-900 bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-200 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 ">
                                                                View
                                                            </button>
                                                        </a>
                                                    <?php endif; ?>
                                                <?php endif; ?>



                                            </div>


                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <div class="flex flex-col md:flex-row mx-auto">
                                        <div class="px-4 w-full flex flex-col justify-around ">
                                            <img src="<?php echo e(asset('img/wishlist.svg')); ?>" alt="No wish"
                                                class="block h-2/4 w-2/4  mx-auto">
                                            <p class="font-bold block mx-auto">No Bookings. Explore more.</p>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>




                        </div>
                    </div>



                </div>
            </div>

        </div>
    </div>



    <?php $__env->startPush('scripts'); ?>
        <script>
            //delete
            $(".delete-listing").click(function(e) {
                e.preventDefault();
                swal({
                        title: "Are you sure to cancel?",
                        text: "Once you cancelled, theres no turning back!",
                        icon: "warning",
                        buttons: true,
                        dangerMode: true,
                    })
                    .then((willDelete) => {
                        if (willDelete) {
                            $(e.target)
                                .closest("form")
                                .submit(); // Post the surrounding form
                        } else {
                            return false;
                        }
                    });
            });
        </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5166c0e64f8fa13f0ef83a121d0e097bbcd4aa85)): ?>
<?php $component = $__componentOriginal5166c0e64f8fa13f0ef83a121d0e097bbcd4aa85; ?>
<?php unset($__componentOriginal5166c0e64f8fa13f0ef83a121d0e097bbcd4aa85); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Finna-Ruma\resources\views/pages/my-bookings.blade.php ENDPATH**/ ?>