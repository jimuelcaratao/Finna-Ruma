<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>


    <div class="projects-section">
        <div class="projects-section-header">
            <p><?php echo e($dayTerm); ?>, <?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->lastname); ?>!</p>
            <p class="time"><?php echo e(Carbon\Carbon::now()->format('M d Y')); ?></p>
        </div>
        <div class="projects-section-line">
            <div class="projects-status">
                <div class="item-status">
                    <span class="status-number"><?php echo e($listing_pending); ?></span>
                    <span class="status-type">Pending Lists</span>
                </div>
                <div class="item-status">
                    <span class="status-number"><?php echo e($listing_approved); ?></span>
                    <span class="status-type">Approved</span>
                </div>
                <div class="item-status">
                    <span class="status-number"><?php echo e($listing_total); ?></span>
                    <span class="status-type">Total Listings</span>
                </div>
            </div>

        </div>

        <div class="project-boxes jsGridView overflow-hidden h-80">

            <div class="project-box-wrapper">
                <div class="project-box" style="background-color: #fee4cb;">
                    <div class="project-box-header">
                        <span></span>
                        <div class="more-wrapper">
                            <a href="<?php echo e(route('admin.rentals')); ?>?search_status=Pending+Approval&search=">
                                <button class="project-btn-more">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-gray-700"
                                        viewBox="0 0 20 20" fill="currentColor">
                                        <path fill-rule="evenodd"
                                            d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"
                                            clip-rule="evenodd" />
                                    </svg>
                                </button>
                            </a>
                        </div>
                    </div>

                    <div class="project-box-content-header">
                        <p class="box-content-header"><?php echo e($listing_pending); ?></p>
                        <p class="box-content-subheader">Pending Listing Approval</p>
                    </div>

                </div>
            </div>

            <div class="project-box-wrapper">
                <div class="project-box" style="background-color: #ffd3e2;">
                    <div class="project-box-header">
                        <span></span>
                        <div class="more-wrapper">
                            <a href="<?php echo e(route('admin.categories')); ?>">

                                <button class="project-btn-more">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-gray-700"
                                        viewBox="0 0 20 20" fill="currentColor">
                                        <path fill-rule="evenodd"
                                            d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"
                                            clip-rule="evenodd" />
                                    </svg>
                                </button>
                            </a>
                        </div>
                    </div>
                    <div class="project-box-content-header">
                        <p class="box-content-header"><?php echo e($categories); ?></p>
                        <p class="box-content-subheader">Total Categories</p>
                    </div>

                </div>
            </div>




            <div class="project-box-wrapper">
                <div class="project-box" style="background-color: #e9e7fd;">
                    <div class="project-box-header">
                        <span></span>
                        <div class="more-wrapper">

                            <a href="<?php echo e(route('admin.users')); ?>">
                                <button class="project-btn-more">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-gray-700"
                                        viewBox="0 0 20 20" fill="currentColor">
                                        <path fill-rule="evenodd"
                                            d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"
                                            clip-rule="evenodd" />
                                    </svg>
                                </button>
                            </a>
                        </div>
                    </div>
                    <div class="project-box-content-header">
                        <p class="box-content-header"><?php echo e($new_users); ?></p>
                        <p class="box-content-subheader">New Users</p>
                    </div>

                </div>
            </div>

            <div class="project-box-wrapper">
                <div class="project-box" style="background-color: #ffd3e2;">
                    <div class="project-box-header">
                        <span></span>
                        <div class="more-wrapper h-7">

                        </div>
                    </div>
                    <div class="project-box-content-header">
                        <p class="box-content-header"><?php echo e($total); ?></p>
                        <p class="box-content-subheader">Total Bookings</p>
                    </div>

                </div>
            </div>


        </div>


        
        <div class="text-xl font-bold mt-4">
            <p>Latest rentals</p>
        </div>

        <div class="project-boxes jsGridView">

            <?php $__empty_1 = true; $__currentLoopData = $listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="project-box-wrapper">
                    <div class="project-box">

                        <div class="project-box-content-header py-3">
                            <p class="box-content-header"><?php echo e($listing->listing_title); ?></p>
                            <p class="box-content-subheader"><?php echo e($listing->category->category_name); ?></p>
                        </div>

                        <div class="project-box-footer">
                            <div class="participants">
                                
                                <a href="<?php echo e(route('single-list', [$listing->slug])); ?>" target="_blank">
                                    <button class="add-participant" style="color: #096c86;">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none"
                                            viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                            <path stroke-linecap="round" stroke-linejoin="round"
                                                d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                            <path stroke-linecap="round" stroke-linejoin="round"
                                                d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                                        </svg>
                                    </button>
                                </a>
                            </div>
                            <div class="days-left" style="color: #096c86;">
                                ₱ <?php echo number_format($listing->price_per_night, 2); ?> Per night
                            </div>
                        </div>
                    </div>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                <div class="text-center pt-10 px-2 mx-auto">
                    No data available...
                </div>
            <?php endif; ?>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Finna-Ruma\resources\views/pages/admin/dashboard.blade.php ENDPATH**/ ?>