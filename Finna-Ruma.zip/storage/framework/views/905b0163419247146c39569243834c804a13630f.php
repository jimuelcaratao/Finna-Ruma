<?php if (isset($component)) { $__componentOriginalc613092c07972ff6fa4c4579892de5d3d9b6a360 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\HostLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('host-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\HostLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    
    

    <!-- Modal -->
    <div class="modal fade" id="searchFilter" tabindex="-1" aria-labelledby="searchFilterLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="searchFilterLabel">Modal title</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    ...
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Save changes</button>
                </div>
            </div>
        </div>
    </div>

    
    <div class="projects-section">
        <div class="projects-section-header">
            <p>My Listing</p>
            
        </div>

        <div class="projects-section-line">
            <div class="projects-status">
                <div class="item-status">
                    <span class="status-number"><?php echo e($listing_pending); ?></span>
                    <span class="status-type">Pending Approval</span>
                </div>
                <div class="item-status">
                    <span class="status-number"><?php echo e($listing_approved); ?></span>
                    <span class="status-type">Approved</span>
                </div>
                <div class="item-status">
                    <span class="status-number"><?php echo e($listing_denied); ?></span>
                    <span class="status-type">Denied</span>
                </div>
                <div class="item-status">
                    <span class="status-number"><?php echo e(count($listings)); ?></span>
                    <span class="status-type">Total</span>
                </div>
            </div>
            <div class="view-actions">
                <div class="search-wrapper-v2 mr-4">

                    <form id="search_tbl" style="outline: none;">
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 flex items-center">
                                <label for="search_status" class="sr-only">Users role</label>
                                <select id="search_status" name="search_status"
                                    class="focus:ring-indigo-500 focus:border-indigo-500 h-full py-0 pl-2 pr-12 border-transparent bg-transparent text-gray-500 sm:text-sm rounded-md">
                                    <?php if(!empty(request()->search_status)): ?>
                                        <option class="bg-gray-200" disabled selected="<?php echo e(request()->search_status); ?>">
                                            <?php echo e(request()->search_status); ?>

                                        </option>
                                    <?php endif; ?>
                                    <option class="text-xs py-2 font-bold uppercase" disabled>
                                        Status</option>
                                    <option value="">
                                        All</option>
                                    <option value="Pending Approval">
                                        Pending Approval</option>
                                    <option value="Unavailable">
                                        Unavailable</option>
                                    <option value="Approved">
                                        Approved</option>
                                    <option value="Denied">
                                        Denied</option>
                                </select>
                                
                            </div>

                            <input id="search_inp" class="ml-40 search-input outline-offset-4" type="search"
                                name="search" placeholder="Search" value="<?php echo e(request()->search); ?>"
                                style="outline: none;">
                        </div>
                    </form>
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none"
                        stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        class="search_btn feather feather-search cursor-pointer" viewBox="0 0 24 24">
                        <defs></defs>
                        <circle cx="11" cy="11" r="8"></circle>
                        <path d="M21 21l-4.35-4.35"></path>
                    </svg>
                </div>

                


                <a href="<?php echo e(route('host.add.listing')); ?>" class="bg-gray-800 text-white p-2 rounded-full"
                    title="Add New Project">
                    <svg class="btn-icon" xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                        viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"
                        stroke-linejoin="round" class="feather feather-plus">
                        <line x1="12" y1="5" x2="12" y2="19" />
                        <line x1="5" y1="12" x2="19" y2="12" />
                    </svg>
                </a>
            </div>
        </div>

        <div class="overflow-y-auto">
            <div class="relative  shadow-sm">
                <table class="w-full text-sm text-left text-gray-500 ">
                    <thead class="text-xs text-gray-700 uppercase bg-gray-50 ">
                        <tr>
                            <th scope="col" class="px-6 py-3">
                                Listing name
                            </th>

                            <th scope="col" class="px-6 py-3">
                                Status
                            </th>

                            <th scope="col" class="px-6 py-3">
                                Availability
                            </th>

                            <th scope="col" class="px-6 py-3">
                                Category
                            </th>

                            <th scope="col" class="px-6 py-3">
                                Location
                            </th>

                            <th scope="col" class="px-6 py-3">
                                Price
                            </th>

                            <th scope="col" class="px-6 py-3">
                                Property Size
                            </th>

                            <th scope="col" class="px-6 py-3">
                                Guest
                            </th>

                            <th scope="col" class="px-6 py-3">
                                <span class="sr-only no-underline">Edit</span>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="bg-white border-b  ">
                                <th scope="row" class="px-6 py-3 font-medium text-gray-900  whitespace-nowrap">
                                    <?php echo e(\Illuminate\Support\Str::limit($listing->listing_title, 50)); ?>

                                </th>

                                <td class="px-6 py-3">


                                    <?php if($listing->listing_status == 'Denied'): ?>
                                        <span
                                            class="text-white px-2.5 py-0.5 rounded bg-gradient-to-r from-red-500  to-red-600">
                                            <?php echo e($listing->listing_status); ?>

                                        </span>
                                    <?php elseif($listing->listing_status == 'Approved'): ?>
                                        <span
                                            class="text-white px-2.5 py-0.5 rounded bg-gradient-to-r from-green-500  to-green-600">
                                            <?php echo e($listing->listing_status); ?>

                                        </span>
                                    <?php else: ?>
                                        <span
                                            class="text-white px-2.5 py-0.5 rounded bg-gradient-to-r from-gray-500  to-gray-600">
                                            <?php echo e($listing->listing_status); ?>

                                        </span>
                                    <?php endif; ?>
                                </td>

                                <td class="px-6 py-3">
                                    <?php if($listing->availability == 'Unavailable'): ?>
                                        <span
                                            class="text-white px-2.5 py-0.5 rounded bg-gradient-to-r from-purple-500  to-purple-600">
                                            <?php echo e($listing->availability); ?>

                                        </span>
                                    <?php else: ?>
                                        <span
                                            class="text-white px-2.5 py-0.5 rounded bg-gradient-to-r from-green-500  to-green-600">
                                            <?php echo e($listing->availability); ?>

                                        </span>
                                    <?php endif; ?>
                                </td>


                                <td class="px-6 py-3">
                                    <?php echo e($listing->category->category_name); ?>


                                </td>

                                <td class="px-6 py-3">
                                    <?php echo e(\Illuminate\Support\Str::limit($listing->location, 40)); ?>

                                </td>

                                <td class="px-6 py-3 ">
                                    ₱ <?php echo number_format($listing->price_per_night, 2); ?>
                                </td>

                                <td class="px-6 py-3 ">
                                    <?php echo e($listing->property_size); ?> sq. m
                                </td>

                                <td class="px-6 py-3 ">
                                    <?php echo e($listing->max_guest); ?>

                                </td>

                                <td class="px-6 py-3 text-right flex justify-end mt-2">

                                    
                                    <div id="tooltip-edit" role="tooltip"
                                        class="inline-block absolute invisible z-10 py-2 px-3 text-sm font-medium text-white bg-gray-900 rounded-lg shadow-sm opacity-0 tooltip dark:bg-gray-700">
                                        Edit Listing
                                        <div class="tooltip-arrow" data-popper-arrow></div>
                                    </div>


                                    
                                    <div id="tooltip-delete" role="tooltip"
                                        class="inline-block absolute invisible z-10 py-2 px-3 text-sm font-medium text-white bg-gray-900 rounded-lg shadow-sm opacity-0 tooltip dark:bg-gray-700">
                                        Delete
                                        <div class="tooltip-arrow" data-popper-arrow></div>
                                    </div>

                                    <a href="<?php echo e(route('host.edit.listing', [$listing->slug])); ?>"
                                        data-tooltip-target="tooltip-edit" data-tooltip-placement="top"
                                        class="font-medium text-purple-600  hover:text-purple-900  hover:underline no-underline"><svg
                                            xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20"
                                            fill="currentColor">
                                            <path
                                                d="M17.414 2.586a2 2 0 00-2.828 0L7 10.172V13h2.828l7.586-7.586a2 2 0 000-2.828z" />
                                            <path fill-rule="evenodd"
                                                d="M2 6a2 2 0 012-2h4a1 1 0 010 2H4v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H4a2 2 0 01-2-2V6z"
                                                clip-rule="evenodd" />
                                        </svg></a>


                                    <form class="delete-listing ml-2"
                                        action="<?php echo e(route('host.listing.destroy', [$listing->listing_id])); ?>"
                                        method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <a type="submit" data-tooltip-target="tooltip-delete"
                                            data-tooltip-placement="top"
                                            class="font-medium text-red-600 no-underline hover:text-red-900"><svg
                                                xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none"
                                                viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                <path stroke-linecap="round" stroke-linejoin="round"
                                                    d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                            </svg></a>
                                    </form>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8"
                                    class="pr-4 py-8 whitespace-nowrap text-sm font-medium text-center">
                                    <img class="mx-auto d-block text-center py-4" style="width: 275px"
                                        src="<?php echo e(asset('img/global/empty.svg')); ?>" alt="no categories">
                                    Hmmm.. There is no listing in here.
                                </td>
                            </tr>
                        <?php endif; ?>


                    </tbody>
                </table>
            </div>

            <div class="row justify-content-center">
                <div class="mt-4 d-flex justify-content-center">
                    
                    <div class="pagination">
                        
                        <?php echo e($listings->appends(Request::except('page'))->render('pagination::bootstrap-4')); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>


    <?php $__env->startPush('scripts'); ?>
        <script>
            $('.brand-radio').click(function() {
                brand = $('input[name="brand_type"]:checked').val();

                $('#brand-form').submit();
            });

            $('.stock-radio').click(function() {
                brand = $('input[name="stock_type"]:checked').val();

                $('#stock-form').submit();
            });

            $('#brand_type_clear').click(function() {

                $('input[name="brand_type"][value=<?php echo e(request()->brand_type); ?>]').prop("checked", false);
                $('#brand-form').submit();
            });

            $('#stock_type_clear').click(function() {

                $('input[name="stock_type"][value=<?php echo e(request()->stock_type); ?>]').prop("checked", false);
                $('#brand-form').submit();
            });

            window.document.onload = $(document).ready(function() {
                if ('<?php echo e(request()->brand_type); ?>' != '') {
                    $('input[name="brand_type"][value=<?php echo e(request()->brand_type); ?>]').prop("checked", true);
                }

                if ('<?php echo e(request()->stock_type); ?>' != '') {
                    $('input[name="stock_type"][value=<?php echo e(request()->stock_type); ?>]').prop("checked", true);
                }
            });

            $(document).ready(function() {

                $(".search_btn").click(function() {
                    $("#search_tbl").submit();
                });

                $('#search_status').on('change', function() {
                    $("#search_tbl").submit();
                });
            });
            //delete
            $(".delete-listing").click(function(e) {
                e.preventDefault();
                swal({
                        title: "Are you sure to Delete?",
                        text: "Once you Deleted, theres no turning back!",
                        icon: "warning",
                        buttons: true,
                        dangerMode: true,
                    })
                    .then((willDelete) => {
                        if (willDelete) {
                            $(e.target)
                                .closest("form")
                                .submit(); // Post the surrounding form
                        } else {
                            return false;
                        }
                    });
            });
        </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc613092c07972ff6fa4c4579892de5d3d9b6a360)): ?>
<?php $component = $__componentOriginalc613092c07972ff6fa4c4579892de5d3d9b6a360; ?>
<?php unset($__componentOriginalc613092c07972ff6fa4c4579892de5d3d9b6a360); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Finna-Ruma\resources\views/pages/host/my-listings.blade.php ENDPATH**/ ?>